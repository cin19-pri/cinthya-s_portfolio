# Project memory

## Product intent & audience

- Personal portfolio website for Cinthya Prieto (CP)
- Showcases professional achievements: scholarships, English competition awards, Tecnolochicas program, CONALEP credentials
- Includes CV download and contact options
- Audience: potential employers, academic institutions, professional contacts

## Brand personality & voice

- Professional, achievement-focused personal branding
- Spanish-language content (user communicates in Spanish; responses in Spanish)

## Visual design & UX direction

- Navbar: personal logo "CP" on left side (Lucide icon-based)
- Footer: contact icons for WhatsApp, phone, and email (removed GitHub/LinkedIn)
- Removed floating cards overlay from main image
- Image placeholder frames display expected path when file missing
- Prefers Lucide React icons throughout

## Decisions, constraints & rationale

- Images organized in `public/assets/` with subdirectory `public/assets/talleres/` for workshop images
- Expected filenames (exact match required): `mi-foto.jpg`, `cv-cinthya-prieto.pdf`, `evidencia-beca.jpg`, `evidencia-ingles-1er-lugar.jpg`, `evidencia-tecnolochicas.jpg`, `evidencia-conalep.jpg`
- Credential image filenames already defined in page data file
- Uploaded `public/assets/images/image.png` was a page screenshot, not used; can be deleted
- Placeholder frames show expected path when matching file is missing
- No external UI packages installed; using Tailwind + Lucide React only

## Open questions & assumptions

- Phone number and WhatsApp contact values still need to be provided by user (currently placeholder/example values)
- Exact list of credential image filenames not yet documented (defined in page data file)
- User may request further personalization of content/images once assets are placed